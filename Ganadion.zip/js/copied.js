function lblMail(){
    var b = document.getElementById("boton-mail");
    b.setAttribute('data-original-title', 'Copiado');
    $(b).tooltip('show');
    b.setAttribute('data-original-title', 'Copiar');
}

function lblTelefono(){
	var b = document.getElementById("boton-telefono");
    b.setAttribute('data-original-title', 'Copiado');
    $(b).tooltip('show');
    b.setAttribute('data-original-title', 'Copiar');
}

function lblUbicacion(){
	var b = document.getElementById("boton-ubicacion");
    b.setAttribute('data-original-title', 'Copiado');
    $(b).tooltip('show');
    b.setAttribute('data-original-title', 'Copiar');
}